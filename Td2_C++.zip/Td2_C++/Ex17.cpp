#include <iostream>
using namespace std;
 
int main(){
	string st;
	string jour, mois, annee, heur, min;
	
	cout << "Veuillez saisir une chaine de caracteres contenant une date et une heure sous la forme JJMMAAAAHHNN: " << endl;
	cin >> st;
	
	jour = st.substr(0, 2);
	mois = st.substr(2, 2);
	annee = st.substr(4, 4);
	heur = st.substr(8, 2);
	min = st.substr(10, 2);
	
	cout << "Cette chaine represente la date: " << jour << " / " << mois << " / " << annee << " a " << heur << "h" << min << endl;
 
    return 0;
}
