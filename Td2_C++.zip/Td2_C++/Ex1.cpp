#include <iostream>
using namespace std;

int i=1;
void AppelNumb() {
    cout << "Apple Numero" << i++ << endl;
}
int main(){
    AppelNumb();
    AppelNumb();
    AppelNumb();
    return 0;
}