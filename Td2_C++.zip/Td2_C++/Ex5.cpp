#include <iostream>
using namespace std;

int main() {
    int a = 5;
    int& ref_a = a;
    int* p_a = &a;

    cout << "Déclaration d'un entier a : " << a << endl;
    cout << "Adresse de a : " << &a << endl;

    cout << "Déclaration d'une référence ref_a : " << ref_a << endl;
    cout << "Adresse de ref_a : " << &ref_a << endl;

    cout << "Déclaration d'un pointeur p_a : " << *p_a << endl;
    cout << "Adresse stockée dans p_a : " << p_a << endl;

    return 0;
}
